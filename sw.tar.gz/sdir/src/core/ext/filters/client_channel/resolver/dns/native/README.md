dns: scheme name resolution, using getaddrbyname
(or other OS specific implementation)
